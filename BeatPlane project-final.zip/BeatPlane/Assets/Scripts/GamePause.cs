﻿using UnityEngine;
using System.Collections;

public class GamePause : MonoBehaviour {

	void OnMouseUpAsButton() {
		print ("click me!");
		GameManager._instance.transfromGameState();

		audio.Play();
	}

}
