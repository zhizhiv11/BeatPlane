﻿using UnityEngine;
using System.Collections;

public class ReStart : MonoBehaviour {
    void OnMouseUpAsButton() {
        Application.LoadLevel(0);
    }
}
