﻿using UnityEngine;
using System.Collections;

public class Quit : MonoBehaviour {

    void OnMouseUpAsButton() {
        Application.Quit();
    }
}
